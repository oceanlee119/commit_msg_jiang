Thank you for downloading this reproducibility package.

- You can use git to see the differences I made to nematus.

- In the subfolder, "commitgen": runwrap.sh has the commands for training and testing nematus using the data files in the subfolder "data"

If you have any question, please reach out and email: sjiang1@nd.edu

Siyuan Jiang
Dec. 29, 2017