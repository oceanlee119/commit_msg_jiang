NMT2:

The data files for NMT2 (in the ASE paper)

test.3000.diff is the test1 data file.
test_non_specific.diff is the test2 data file.

